/*********************************
 * DEFINE ALL EXTERNAL LIBRARIES *
 *    AND CONTROL STATES HERE    *
 *********************************/
#ifndef A_RTC_CONFIG_h
#define A_RTC_CONFIG_h

#include <Arduino.h>
#include <Ticker.h>

/* All custom headers below */
#include "enum.h"
#include "ControlIO.h"
// #include "Logging.h"

#include "ObjRtc.h"
#include "rtc.h"

/**************************
 * WRITE CUSTOM SHIT BELOW *
 **************************/




/***************************************************
 * THIS FILE SHOULD CONTAIN WHAT THE PROJECT NEEDS *
 *  INCLUDE ALL THE FUNCTIONS/FEATURES NEEDED FOR  *
 *                  YOUR PROJECT                   *
 ***************************************************/

#endif